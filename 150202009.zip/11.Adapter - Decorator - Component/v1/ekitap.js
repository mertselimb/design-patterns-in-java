import adapter from "adapter.js";

class eKitap extends adapter {
    constructor(ulasimID){
        this.ulasimID = ulasimID;
        this.ID = ID;
        this.isim = isim;
        this.cikisTarihi = cikisTarihi;
        this.basim = basim;
        this.sayfaSayisi = sayfaSayisi;
        this.tanitim = tanitim;
        this.bilgileriGetirOZEL = null;
    }
  }

export default eKitap;