import kitap from "kitap.js";

class miniKitap extends kitap {
    constructor(sayfa){
    	this.ID = ID;
        this.isim = isim;
        this.cikisTarihi = cikisTarihi;
        this.basim = basim;
        this.sayfaSayisi = sayfaSayisi;
        this.tanitim = tanitim;
        this.ozelSayfaSayisi = sayfa;
        this.bilgileriGetir = null;
    }
  }

export default miniKitap;