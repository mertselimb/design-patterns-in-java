import kitap from "kitap.js";

class ozelBasimKitap extends kitap {
    constructor(basimSayisi){
    	this.ID = ID;
        this.isim = isim;
        this.cikisTarihi = cikisTarihi;
        this.basim = basim;
        this.sayfaSayisi = sayfaSayisi;
        this.tanitim = tanitim;
        this.basimSayisi = basimSayisi;
        this.bilgileriGetir = null;
    }
  }

export default ozelBasimKitap;