class kitap {
    constructor(isim, cikisTarihi, basim, sayfaSayisi, tanitim) {
        this.ID = ID;
        this.isim = isim;
        this.cikisTarihi = cikisTarihi;
        this.basim = basim;
        this.sayfaSayisi = sayfaSayisi;
        this.tanitim = tanitim;
        this.bilgileriGetir = null;
    }
}


export default kitap;