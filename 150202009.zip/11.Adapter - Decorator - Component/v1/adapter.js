import kitap from "kitap.js";

class adaptor extends kitap {
    constructor(ulasimID){
        this.bilgileriGetir = bilgileriGetirOZEL;
    }
  }

export default adaptor;