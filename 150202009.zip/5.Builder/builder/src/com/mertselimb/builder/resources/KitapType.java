package com.mertselimb.builder.resources;

public enum KitapType {
    KITAP,EKITAP,MINIKITAP
}
