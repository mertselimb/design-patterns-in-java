package com.mertselimb.observer.models;

public abstract class Observer {
    protected Denek denek;
    abstract void update();
}
