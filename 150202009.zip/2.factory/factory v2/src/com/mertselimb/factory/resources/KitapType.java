package com.mertselimb.factory.resources;

public enum KitapType {
    KITAP,EKITAP,MINIKITAP
}
