package com.mertselimb.abstractFactory.resources;

public enum KitapType {
    KITAP,EKITAP,MINIKITAP
}
