package com.mertselimb.abstractFactory.resources;

public enum FactoryType {
    KITAP,BASKA
}
