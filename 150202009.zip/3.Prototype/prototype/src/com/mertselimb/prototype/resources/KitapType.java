package com.mertselimb.prototype.resources;

public enum KitapType {
    KITAP,EKITAP,MINIKITAP
}
