package com.mertselimb.objectPool.resources;

public enum KitapType {
    KITAP,EKITAP,MINIKITAP
}
