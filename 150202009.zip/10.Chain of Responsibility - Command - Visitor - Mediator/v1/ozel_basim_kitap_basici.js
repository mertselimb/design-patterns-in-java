export class ozel_basim_kitap_basici {
    yeniKitap(isim, cikisTarihi, basim, sayfaSayisi, tanitim, basim_sayisi) {
        return function(){
        this.ID = ID;
        this.isim = isim;
        this.cikisTarihi = cikisTarihi;
        this.basim = basim;
        this.sayfaSayisi = sayfaSayisi;
        this.tanitim = tanitim;
    	this.ozel_sayfa_sayisi = basim_sayisi };
    }


}
