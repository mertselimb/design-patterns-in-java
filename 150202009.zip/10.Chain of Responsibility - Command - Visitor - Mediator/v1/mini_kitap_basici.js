export class mini_kitap_basici {
    yeniKitap(isim, cikisTarihi, basim, sayfaSayisi, tanitim, ozel_sayfa_sayisi) {
        return function(){
        this.ID = ID;
        this.isim = isim;
        this.cikisTarihi = cikisTarihi;
        this.basim = basim;
        this.sayfaSayisi = sayfaSayisi;
        this.tanitim = tanitim;
    	this.ozel_sayfa_sayisi = ozel_sayfa_sayisi };
    }


}