import kitap from "kitap.js";

class ozelBasimKitap extends kitap {
    constructor(basimSayisi){
        this.basimSayisi = basimSayisi;
    }
  }

export default ozelBasimKitap;