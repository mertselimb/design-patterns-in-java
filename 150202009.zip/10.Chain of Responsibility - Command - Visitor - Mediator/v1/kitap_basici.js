class kitap_basici {
    yeniKitap(isim, cikisTarihi, basim, sayfaSayisi, tanitim) {
        return function(){
        this.ID = ID;
        this.isim = isim;
        this.cikisTarihi = cikisTarihi;
        this.basim = basim;
        this.sayfaSayisi = sayfaSayisi;
        this.tanitim = tanitim};
    }


}


export default kitap_basici;