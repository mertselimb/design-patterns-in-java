export class ekitap_basici {
    yeniKitap(isim, cikisTarihi, basim, sayfaSayisi, tanitim, ulasim_id) {
        return function(){
        this.ID = ID;
        this.isim = isim;
        this.cikisTarihi = cikisTarihi;
        this.basim = basim;
        this.sayfaSayisi = sayfaSayisi;
        this.tanitim = tanitim;
    	this.ulasim_id = ulasim_id };
    }



}
