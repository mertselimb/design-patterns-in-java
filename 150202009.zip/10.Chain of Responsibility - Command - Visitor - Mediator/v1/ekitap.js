import kitap from "kitap.js";

class eKitap extends kitap {
    constructor(ulasimID){
        this.ulasimID = ulasimID;
    }
  }

export default eKitap;