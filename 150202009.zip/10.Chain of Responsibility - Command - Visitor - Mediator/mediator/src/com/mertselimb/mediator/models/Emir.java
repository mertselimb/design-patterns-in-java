package com.mertselimb.mediator.models;

public interface Emir {
    void uygula();
}
